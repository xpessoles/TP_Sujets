#ifndef CF_ascenseur_simplev2_H__
#define CF_ascenseur_simplev2_H__
#endif
