#include "__cf_ascenseur_simplev2.h"
#include "ascenseur_simplev2_acc.h"
#include "ascenseur_simplev2_acc_private.h"
P_ascenseur_simplev2_T ascenseur_simplev2_rtDefaultP = { 10.0 , 1.0 , 0.0 ,
0.1 , 1000.0 , 0.03 , 1000.0 , 0.03 , 1000.0 , 0U , 0U , 0U , 0U , 1U , 0U ,
0U , 0U , 0U , { 'a' , 'a' , 'a' , 'a' , 'a' , 'a' , 'a' } } ;
