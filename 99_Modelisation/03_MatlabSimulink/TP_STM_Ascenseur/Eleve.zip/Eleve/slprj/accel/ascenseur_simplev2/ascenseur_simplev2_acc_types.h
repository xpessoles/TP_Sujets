#include "__cf_ascenseur_simplev2.h"
#ifndef RTW_HEADER_ascenseur_simplev2_acc_types_h_
#define RTW_HEADER_ascenseur_simplev2_acc_types_h_
#include "rtwtypes.h"
typedef struct P_ascenseur_simplev2_T_ P_ascenseur_simplev2_T ;
#endif
